select a.*
from (require(base.sql)) as a
order by a.order_index,a.code