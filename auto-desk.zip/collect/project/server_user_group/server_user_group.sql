SELECT *
FROM os_soft_user_group a
WHERE a.user_goup_src = "1"