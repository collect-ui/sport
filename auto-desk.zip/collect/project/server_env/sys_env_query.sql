select a.*
from sys_env a